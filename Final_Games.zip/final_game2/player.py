from items import *
from map import rooms

inventory = [item_id, item_laptop, item_money]

# Start game at the reception
current_room = rooms["Reception"]

def current_carry(inventory):
    sum_mass = 0.0
    for item in inventory:
        sum_mass = sum_mass + item["mass"]
    return sum_mass